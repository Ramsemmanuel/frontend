export const environment = {
  production: true,
  firebase: {
    apiKey: "AIzaSyB5iWes_2Ckh7hP505AmccABz1z7KiXtMA",
    authDomain: "competition-site-116cf.firebaseapp.com",
    databaseURL: "https://competition-site-116cf.firebaseio.com",
    projectId: "competition-site-116cf",
    storageBucket: "competition-site-116cf.appspot.com",
    messagingSenderId: "52622702751",
    appId: "1:52622702751:web:d6e8a4fcaa15f5c8c48aaa",
    measurementId: "G-8GC8GSFXSC"
  }
};
